// import 'package:flutter/material.dart';
// import 'package:dio/dio.dart';

// class TrendingList extends StatefulWidget {
//   const TrendingList({super.key});

//   @override
//   _TrendingListState createState() => _TrendingListState();
// }

// class _TrendingListState extends State<TrendingList> {
//   late Future<List<Product>> _futureProducts;

//   @override
//   void initState() {
//     super.initState();
//     _futureProducts = fetchProducts();
//   }

//   Future<List<Product>> fetchProducts() async {
//     try {
//       final dio = Dio();
//       final response = await dio.get('https://dummyjson.com/products/category/groceries');
//       if (response.statusCode == 200) {
//         List products = response.data['products'];
//         return products.map((json) => Product.fromJson(json)).toList();
//       } else {
//         throw Exception('Failed to load products');
//       }
//     } catch (e) {
//       throw Exception('Failed to load products: $e');
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder<List<Product>>(
//       future: _futureProducts,
//       builder: (context, snapshot) {
//         if (snapshot.connectionState == ConnectionState.waiting) {
//           return const Center(child: CircularProgressIndicator());
//         } else if (snapshot.hasError) {
//           return Center(child: Text('Error: ${snapshot.error}'));
//         } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
//           return const Center(child: Text('No products found'));
//         }

//         final products = snapshot.data!;
//         return SliverGrid(
//           gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//             crossAxisCount: 2,
//             childAspectRatio: 0.7,
//           ),
//           delegate: SliverChildListDelegate(
//     products.map((product) {
//       return TrendingItem(
//         imagePath: product.thumbnail,
//         name: product.title,
//         price: '\$${product.price}',
//       );
//     }).toList(),
//   ),
//         );
//       },
//     );
//   }
// }

// class Product {
//   final String title;
//   final String thumbnail;
//   final double price;

//   Product({
//     required this.title,
//     required this.thumbnail,
//     required this.price,
//   });

//   factory Product.fromJson(Map<String, dynamic> json) {
//     return Product(
//       title: json['title'],
//       thumbnail: json['thumbnail'],
//       price: json['price'].toDouble(),
//     );
//   }
// }

// class TrendingItem extends StatelessWidget {
//   const TrendingItem({
//     super.key,
//     required this.imagePath,
//     required this.name,
//     required this.price,
//   });

//   final String imagePath;
//   final String name;
//   final String price;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsets.all(8.0),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(16),
//         image: DecorationImage(
//           image: NetworkImage(imagePath),
//           fit: BoxFit.cover,
//         ),
//       ),
//       child: Stack(
//         children: [
//           const Positioned(
//             top: 8,
//             right: 8,
//             child: Icon(Icons.favorite_border, color: Colors.white),
//           ),
//           Positioned(
//             bottom: 8,
//             left: 8,
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   name,
//                   style: const TextStyle(
//                     fontSize: 16,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.white,
//                   ),
//                 ),
//                 Text(
//                   price,
//                   style: TextStyle(
//                     fontSize: 14, color: Colors.white.withOpacity(0.9)),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }