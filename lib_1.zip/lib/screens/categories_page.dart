import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:grocery_1/screens/prod_categ.dart';
// import 'package:_try/product.dart';
class CategoryScreen extends StatefulWidget {
  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  Map<String, List<dynamic>> _categorizedProducts = {}; // لتخزين المنتجات حسب الفئات

  @override
  void initState() {
    super.initState();
    _fetchGroceries();
  }

  // دالة استدعاء API
  Future<void> _fetchGroceries() async {
    try {
      var dio = Dio();
      var response = await dio.get('https://dummyjson.com/products/category/groceries');
      List<dynamic> products = response.data['products'];

      // تصنيف المنتجات حسب الفئات الموجودة في tags
      Map<String, List<dynamic>> categorizedProducts = {
        'Fruits': [],
        'Vegetables': [],
        'Mushroom': [],
        'Dairy': [],
        'Oats': [],
        'Bread': [],
        'Rice': [],
        'Egg': [],
        'Others': []
      };

      for (var product in products) {
        List<dynamic> tags = product['tags'];

        if (tags.contains('fruits')) {
          categorizedProducts['Fruits']?.add(product);
        } else if (tags.contains('vegetables') || tags.contains('veg')) {
          categorizedProducts['Vegetables']?.add(product);
        } else if (tags.contains('mushroom')) {
          categorizedProducts['Mushroom']?.add(product);
        } else if (tags.contains('dairy')) {
          categorizedProducts['Dairy']?.add(product);
        } else if (tags.contains('oat')) {
          categorizedProducts['Oats']?.add(product);
        } else if (tags.contains('bread')) {
          categorizedProducts['Bread']?.add(product);
        } else if (tags.contains('rice')) {
          categorizedProducts['Rice']?.add(product);
        } else if (tags.contains('egg')) {
          categorizedProducts['Egg']?.add(product);
        } else {
          categorizedProducts['Others']?.add(product); // لأي منتج لا ينتمي إلى التصنيفات المعروفة
        }
      }

      setState(() {
        _categorizedProducts = categorizedProducts; // تعيين المنتجات المصنفة
      });
    } catch (e) {
      print("Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return _categorizedProducts.isEmpty
        ? Center(child: CircularProgressIndicator()) // عرض مؤقت إذا لم تكن البيانات جاهزة
        : GridView.count(
            crossAxisCount: 2,
            padding: EdgeInsets.all(16.0),
            crossAxisSpacing: 10.0,
            mainAxisSpacing: 10.0,
            children: _categorizedProducts.keys.map((category) {
              return _buildCategoryCard(
                  category, _categorizedProducts[category]??[]);
            }).toList(),
          );
  }

  // تصميم بطاقة (Card) لكل فئة
  Widget _buildCategoryCard(String categoryName, List<dynamic> products) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      elevation: 4.0,
      child: InkWell(
        onTap: () {
          // من الممكن إضافة دالة للنقل إلى صفحة التفاصيل
           Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProductListScreen(
                categoryName: categoryName,
                products: products,
              ),
            ),
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // يمكن استبدال الصور بصور أكثر دقة لفئاتك
            Icon(
              _getCategoryIcon(categoryName), // جلب الأيقونة بناءً على الفئة
              size: 50.0,
              color: Colors.orange,
            ),
            SizedBox(height: 10.0),
            Text(
              categoryName,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0),
            ),
            SizedBox(height: 5.0),
            // Text('$itemCount items',
            //     style: TextStyle(color: Colors.grey, fontSize: 14.0)),
          ],
        ),
      ),
    );
  }

  // دالة لجلب أيقونة الفئة بناءً على الاسم
  IconData _getCategoryIcon(String categoryName) {
    switch (categoryName) {
      case 'Fruits':
        return Icons.apple;
      case 'Vegetables':
        return Icons.grass;
      case 'Mushroom':
        return Icons.eco;
      case 'Dairy':
        return Icons.local_drink;
      case 'Oats':
        return Icons.breakfast_dining;
      case 'Bread':
        return Icons.bakery_dining;
      case 'Rice':
        return Icons.rice_bowl;
      case 'Egg':
        return Icons.egg;
      default:
        return Icons.fastfood;
    }
  }
}
