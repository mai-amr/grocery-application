  import 'package:flutter/material.dart';

  class TrendingList extends StatelessWidget {
    const TrendingList({super.key});

    @override
    Widget build(BuildContext context) {
      return SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.7,
        ),
        delegate: SliverChildListDelegate(
          [
            const TrendingItem(imagePath: 'assets/image.png', name: 'Avocado', price: '\$6.7'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Broccoli', price: '\$8.7'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Cherry', price: '\$9.5'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Steak', price: '\$15.4'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Avocado', price: '\$6.7'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Broccoli', price: '\$8.7'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Cherry', price: '\$9.5'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Steak', price: '\$15.4'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Avocado', price: '\$6.7'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Broccoli', price: '\$8.7'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Cherry', price: '\$9.5'),
            const TrendingItem(imagePath: 'assets/image.png', name: 'Steak', price: '\$15.4'),
          ],
        ),
      );
    }
  }

  class TrendingItem extends StatelessWidget {
    const TrendingItem({
      super.key,
      required this.imagePath,
      required this.name,
      required this.price,
    });

    final String imagePath;
    final String name;
    final String price;

    @override
    Widget build(BuildContext context) {
      return Container(
        margin: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(
            image: AssetImage(imagePath),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            const Positioned(
              top: 8,
              right: 8,
              child: Icon(Icons.favorite_border, color: Colors.white),
            ),
            Positioned(
              bottom: 8,
              left: 8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  Text(
                    price,
                    style: TextStyle(
                        fontSize: 14, color: Colors.white.withOpacity(0.9)),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
  }
// import 'package:flutter/material.dart';
// import 'package:dio/dio.dart'; // لإضافة مكتبة Dio

// class TrendingList extends StatefulWidget {
//   final String categoryName;

//   TrendingList({required this.categoryName});

//   @override
//   _ProductListScreenState createState() => _ProductListScreenState();
// }

// class _ProductListScreenState extends State<TrendingList> {
//   List<dynamic> products = [];

//   @override
//   void initState() {
//     super.initState();
//     fetchProducts();
//   }

//   // Fetch products from the API using Dio.
//   Future<void> fetchProducts() async {
//     try {
//       Dio dio = Dio();
//       final response = await dio
//           .get('https://dummyjson.com/products/category/groceries');

//       if (response.statusCode == 200) {
//         setState(() {
//           products = response.data['products'];
//         });
//       } else {
//         throw Exception('Failed to load products');
//       }
//     } catch (e) {
//       print("Error: $e");
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(
//           widget.categoryName,
//           style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//         ),
//         backgroundColor: Colors.orange,
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.filter_list),
//             onPressed: () {
//               // Handle filter action
//             },
//           ),
//         ],
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(10.0),
//         child: Column(
//           children: [
//             // Search Bar
//             Padding(
//               padding: const EdgeInsets.symmetric(vertical: 10.0),
//               child: TextField(
//                 decoration: InputDecoration(
//                   hintText: 'Search here',
//                   prefixIcon: const Icon(Icons.search),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(30),
//                     borderSide: BorderSide.none,
//                   ),
//                   filled: true,
//                   fillColor: Colors.grey[200],
//                 ),
//               ),
//             ),
//             // Products Grid
//             Expanded(
//               child: products.isEmpty
//                   ? const Center(child: CircularProgressIndicator())
//                   : GridView.builder(
//                       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//                         crossAxisCount: 2, // Two products per row
//                         mainAxisSpacing: 10,
//                         crossAxisSpacing: 10,
//                         childAspectRatio: 0.75, // Adjust the height of the grid items
//                       ),
//                       itemCount: products.length,
//                       itemBuilder: (context, index) {
//                         var product = products[index];
//                         return ProductCard(product: product);
//                       },
//                     ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // Custom widget for product card
// class ProductCard extends StatelessWidget {
//   final dynamic product;

//   ProductCard({required this.product});

//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(20),
//       ),
//       elevation: 4,
//       child: Stack(
//         children: [
//           // Product Image
//           Positioned.fill(
//             child: ClipRRect(
//               borderRadius: BorderRadius.circular(20),
//               child: Image.network(
//                 product['thumbnail'], // Product image
//                 fit: BoxFit.cover,
//               ),
//             ),
//           ),
//           // Overlay with Product Details
//           Positioned(
//             bottom: 0,
//             left: 0,
//             right: 0,
//             child: Container(
//               padding: const EdgeInsets.all(8),
//               decoration: BoxDecoration(
//                 color: Colors.black.withOpacity(0.5),
//                 borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)),
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     product['title'], // Product name
//                     style: const TextStyle(
//                       color: Colors.white,
//                       fontWeight: FontWeight.bold,
//                       fontSize: 16,
//                     ),
//                     maxLines: 1,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                   const SizedBox(height: 4),
//                   Text(
//                     "\$${product['price']}", // Product price
//                     style: const TextStyle(color: Colors.white),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           // Favorite Icon
//           Positioned(
//             top: 8,
//             right: 8,
//             child: IconButton(
//               icon: const Icon(Icons.favorite_border, color: Colors.white),
//               onPressed: () {
//                 // Handle favorite button
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
