  // import 'package:flutter/material.dart';

  // class TrendingList extends StatelessWidget {
  //   const TrendingList({super.key});

  //   @override
  //   Widget build(BuildContext context) {
  //     return SliverGrid(
  //       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
  //         crossAxisCount: 2,
  //         childAspectRatio: 0.7,
  //       ),
  //       delegate: SliverChildListDelegate(
  //         [
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Avocado', price: '\$6.7'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Broccoli', price: '\$8.7'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Cherry', price: '\$9.5'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Steak', price: '\$15.4'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Avocado', price: '\$6.7'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Broccoli', price: '\$8.7'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Cherry', price: '\$9.5'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Steak', price: '\$15.4'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Avocado', price: '\$6.7'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Broccoli', price: '\$8.7'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Cherry', price: '\$9.5'),
  //           const TrendingItem(imagePath: 'assets/image.png', name: 'Steak', price: '\$15.4'),
  //         ],
  //       ),
  //     );
  //   }
  // }

  // class TrendingItem extends StatelessWidget {
  //   const TrendingItem({
  //     super.key,
  //     required this.imagePath,
  //     required this.name,
  //     required this.price,
  //   });

  //   final String imagePath;
  //   final String name;
  //   final String price;

  //   @override
  //   Widget build(BuildContext context) {
  //     return Container(
  //       margin: const EdgeInsets.all(8.0),
  //       decoration: BoxDecoration(
  //         borderRadius: BorderRadius.circular(16),
  //         image: DecorationImage(
  //           image: AssetImage(imagePath),
  //           fit: BoxFit.cover,
  //         ),
  //       ),
  //       child: Stack(
  //         children: [
  //           const Positioned(
  //             top: 8,
  //             right: 8,
  //             child: Icon(Icons.favorite_border, color: Colors.white),
  //           ),
  //           Positioned(
  //             bottom: 8,
  //             left: 8,
  //             child: Column(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               children: [
  //                 Text(
  //                   name,
  //                   style: const TextStyle(
  //                       fontSize: 16,
  //                       fontWeight: FontWeight.bold,
  //                       color: Colors.white),
  //                 ),
  //                 Text(
  //                   price,
  //                   style: TextStyle(
  //                       fontSize: 14, color: Colors.white.withOpacity(0.9)),
  //                 ),
  //               ],
  //             ),
  //           ),
  //         ],
  //       ),
  //     );
  //   }
  // }
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';



class TrendingList extends StatefulWidget {
  const TrendingList({super.key});

  @override
  _TrendingListState createState() => _TrendingListState();
}

class _TrendingListState extends State<TrendingList> {
  List<dynamic> _products = [];

  @override
  void initState() {
    super.initState();
    _fetchGroceries();
  }

  // استدعاء API لجلب المنتجات
  Future<void> _fetchGroceries() async {
    try {
      var dio = Dio();
      var response = await dio.get('https://dummyjson.com/products/category/groceries');
      setState(() {
        _products = response.data['products']; // تخزين المنتجات التي تم استدعاؤها
      });
    } catch (e) {
      print("Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // إذا كانت البيانات لا تزال تُحمّل
    if (_products.isEmpty) {
      return const SliverToBoxAdapter(
        child: Center(child: CircularProgressIndicator()),
      );
    }

    return SliverGrid(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // عدد الأعمدة
        childAspectRatio: 0.7, // نسبة العرض إلى الارتفاع
        crossAxisSpacing: 10.0, // المسافة الأفقية بين العناصر
        mainAxisSpacing: 10.0, // المسافة الرأسية بين العناصر
      ),
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          var product = _products[index];
          return TrendingItem(
            imagePath: product['images'][0], // الصورة الأولى للمنتج
            name: product['title'],          // عنوان المنتج
            price: '\$${product['price']}',  // السعر
          );
        },
        childCount: _products.length, // عدد المنتجات
      ),
    );
  }
}

class TrendingItem extends StatelessWidget {
  const TrendingItem({
    super.key,
    required this.imagePath,
    required this.name,
    required this.price,
  });

  final String imagePath;
  final String name;
  final String price;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        image: DecorationImage(
          image: NetworkImage(imagePath),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          const Positioned(
            top: 8,
            right: 8,
            child: Icon(Icons.favorite_border, color: Colors.white),
          ),
          Positioned(
            bottom: 8,
            left: 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
                Text(
                  price,
                  style: TextStyle(
                      fontSize: 14, color: Colors.black),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
