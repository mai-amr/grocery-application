import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // leading: IconButton(
        //   icon: Icon(Icons.arrow_back),
        //   onPressed: () {
        //     // رجوع للشاشة السابقة
        //   },
        // ),
        title: const Text('Profile'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          const CircleAvatar(
            radius: 50,
            backgroundImage: AssetImage('assets/profile_image.jpg'), // صورة الملف الشخصي
          ),
          const SizedBox(height: 10),
          const Text(
            'Esther Howard',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 30),
          _buildProfileOption(Icons.person, 'Your Profile'),
          _buildProfileOption(Icons.payment, 'Payment Methods'),
          _buildProfileOption(Icons.shopping_bag, 'My Orders'),
          _buildProfileOption(Icons.settings, 'Settings'),
          _buildProfileOption(Icons.help_center, 'Help Center'),
          _buildProfileOption(Icons.privacy_tip, 'Privacy Policy'),
          _buildProfileOption(Icons.group_add, 'Invite Friends'),
          _buildProfileOption(Icons.logout, 'Log Out'),
        ],
      ),
    );
  }

  Widget _buildProfileOption(IconData icon, String title) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios),
      onTap: () {
        // هنا ضع الأكشن الذي تريده عند الضغط
      },
    );
  }
}
